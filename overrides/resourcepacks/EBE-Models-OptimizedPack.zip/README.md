<div align=center>
  <img src="./pack.png" width="128">
<h2> EBE-Models-OptimizedPack </h2>

EBE models optimized, cull more face! Get more FPS!   
<font color=red>**[Enhanced Block Entities](https://modrinth.com/mod/ebe) Required!** </font>
<h2>Compare</h2>
<h3>Render 1000 chests</h3>

| Before | After |
| :-----------: | :-----------: |
| <img src="https://raw.githubusercontent.com/7777777-4547/EBE-Models-OptimizedPack/image/img/before_2022-12-18_00.48.57.png" width="440"> | <img src="https://raw.githubusercontent.com/7777777-4547/EBE-Models-OptimizedPack/image/img/after_2022-12-18_00.52.25.png" width="440"> |

<h3>Half big chest open action</h3>

| Before | After |
| :-----------: | :-----------: |
| <img src="https://raw.githubusercontent.com/7777777-4547/EBE-Models-OptimizedPack/image/img/before_GIF_2022-12-18_1-32-10.gif" width="440"> | <img src="https://raw.githubusercontent.com/7777777-4547/EBE-Models-OptimizedPack/image/img/after_GIF_2022-12-18_1-30-03.gif" width="440"> |

<h3>UV face culling</h3>

| Before | After |
| :-----------: | :-----------: |
| <img src="https://raw.githubusercontent.com/7777777-4547/EBE-Models-OptimizedPack/image/img/before_2022-12-18_01.48.29.png" width="440"> | <img src="https://raw.githubusercontent.com/7777777-4547/EBE-Models-OptimizedPack/image/img/after_2022-12-18_01.47.57.png" width="440"> |